exports.home = async (req, res) => {
	res.send('Hello World From Keja');
};
