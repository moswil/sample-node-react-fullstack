# node-backend-structure

Contains backend structure for node

### Structure

1. Middleware
2. Handlers
3. Models
