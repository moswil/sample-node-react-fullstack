import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './styling/navbar.css';

const Navbar = () => {
	const location = useLocation();
	const isActive = (path) => location.pathname === path;

	return (
		<div className='navbar'>
			<ul className='navbar-list'>
				<li className='navbar-item'>
					<Link to='/'>Bad Bank</Link>
				</li>

				<li className='navbar-item' style={{ marginLeft: '300px' }}>
					<Link
						to='/create-account'
						className={isActive('/create-account') ? 'active-link' : ''}
					>
						Create Account
					</Link>
				</li>
				<li className='navbar-item'>
					<Link to='/login'>Login</Link>
				</li>
				<li className='navbar-item'>
					<Link to='/deposit'>Deposit</Link>
				</li>
				<li className='navbar-item active-link'>
					<Link to='/withdraw'>Withdraw</Link>
				</li>
				<li className='navbar-item'>
					<Link to='/balance'>Balance</Link>
				</li>
				<li className='navbar-item'>
					<Link to='/all-data'>All Data</Link>
				</li>
				<li className='navbar-item'>
					<Link style={{ backgroundColor: 'yellow', marginLeft: '80px' }}>
						emmah@gmail.com
					</Link>
				</li>
			</ul>
		</div>
	);
};

export default Navbar;
