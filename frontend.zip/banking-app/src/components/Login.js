import React, { useState } from 'react';
import './styling/login.css';
function Login() {
	const [formData, setFormData] = useState({
		email: '',
		password: '',
	});

	const [isFormValid, setIsFormValid] = useState(false);

	const handleChange = (e) => {
		const { name, value } = e.target;
		setFormData({ ...formData, [name]: value });
	};

	const authenticateUser = async () => {
		// Replace this mock data with your actual user data from the backend
		const users = [
			{ email: 'user1@example.com', password: 'password1' },
			{ email: 'user2@example.com', password: 'password2' },
		];

		const { email, password } = formData;

		// Check if the user exists in the mock data
		const user = users.find(
			(u) => u.email === email && u.password === password
		);

		if (user) {
			return true; // Authentication success
		} else {
			return false; // Authentication failure
		}
	};

	const handleSubmit = async (e) => {
		e.preventDefault();

		// Implement authentication logic here
		if (formData.email && formData.password) {
			const isAuthenticated = await authenticateUser();

			if (isAuthenticated) {
				alert('Login success!');
			} else {
				alert('Invalid email or password.');
			}
		} else {
			alert('Please fill in all fields.');
		}
	};

	return (
		<div className='login-form'>
			<h2>Login</h2>
			<form onSubmit={handleSubmit}>
				<div className='form-group'>
					<label htmlFor='email'>Email:</label>
					<input
						type='email'
						name='email'
						id='email'
						value={formData.email}
						onChange={handleChange}
					/>
				</div>
				<div className='form-group'>
					<label htmlFor='password'>Password:</label>
					<input
						type='password'
						name='password'
						id='password'
						value={formData.password}
						onChange={handleChange}
					/>
				</div>
				<button type='submit' disabled={!isFormValid}>
					Login
				</button>
			</form>
		</div>
	);
}

export default Login;
