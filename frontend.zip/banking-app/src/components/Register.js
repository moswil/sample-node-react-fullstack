import React, { useState } from 'react';
import './styling/register.css';

function Registration() {
	const [formData, setFormData] = useState({
		name: '',
		email: '',
		password: '',
	});
	const [isFormValid, setIsFormValid] = useState(false);

	const handleChange = (e) => {
		const { name, value } = e.target;
		setFormData({ ...formData, [name]: value });
	};

	const handleSubmit = async (e) => {
		e.preventDefault();

		// Implement form validation logic here
		if (formData.name && formData.email && formData.password) {
			// Validation passed
			try {
				const response = await fetch('https://your-backend-api-url/register', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(formData),
				});

				if (response.ok) {
					alert('Registration success!');
					setFormData({
						name: '',
						email: '',
						password: '',
					});
					setIsFormValid(false);
				} else {
					alert('Registration failed. Please try again.');
				}
			} catch (error) {
				console.error('Error:', error);
				alert('An error occurred during registration.');
			}
		} else {
			alert('Please fill in all fields.');
		}
	};

	return (
		<div className='registration-form'>
			<h2>Register</h2>
			<form onSubmit={handleSubmit}>
				<div className='form-group'>
					<label htmlFor='name'>Name:</label>
					<input
						type='text'
						name='name'
						id='name'
						value={formData.name}
						onChange={handleChange}
					/>
				</div>
				<div className='form-group'>
					<label htmlFor='email'>Email:</label>
					<input
						type='email'
						name='email'
						id='email'
						value={formData.email}
						onChange={handleChange}
					/>
				</div>
				<div className='form-group'>
					<label htmlFor='password'>Password:</label>
					<input
						type='password'
						name='password'
						id='password'
						value={formData.password}
						onChange={handleChange}
					/>
				</div>
				<button type='submit' disabled={!isFormValid}>
					Register
				</button>
			</form>
		</div>
	);
}

export default Registration;
