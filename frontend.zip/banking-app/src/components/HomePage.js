import React from 'react';

import './styling/home.css';
function Home() {
	return (
		<div className='home'>
			<h2>WELCOME TO THE BANK</h2>
			<h3>For all your banking needs</h3>
			<img src='../../public/homeimage.png' alt='' />
		</div>
	);
}

export default Home;
