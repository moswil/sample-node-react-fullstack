import React, { useEffect, useState } from 'react';
import Card from './common/CardComponent';

function Balance() {
	const [balance, setBalance] = useState(null);

	useEffect(() => {
		// Fetch the balance data from the backend API
		fetch('https://your-backend-api-url/balance')
			.then((response) => response.json())
			.then((data) => {
				setBalance(data.balance);
			})
			.catch((error) => console.error(error));
	}, []);

	return (
		<Card
			bgcolor='primary'
			header='BALANCE'
			body={
				balance !== null ? (
					<div>
						<p>Your current balance is:</p>
						<p>${balance}</p>
					</div>
				) : (
					<p>Loading balance...</p>
				)
			}
		/>
	);
}

export default Balance;
