import React from 'react';
import Card from './common/CardComponent';

import './styling/usertable.css';

function UserTable() {
	// const [users, setUsers] = useState([]);

	// useEffect(() => {
	// 	// Fetch data from the backend API
	// 	fetch('https://your-backend-api-url/users')
	// 		.then((response) => response.json())
	// 		.then((data) => {
	// 			setUsers(data);
	// 		})
	// 		.catch((error) => console.error(error));
	// }, []);

	return (
		<div>
			<Card
				bgcolor='primary'
				header='ALL DATA'
				body={
					<>
						<br />
						<br />
						<table className='user-table'>
							<thead>
								<tr>
									<th>Email</th>
									<th>Name</th>
									<th>Password</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td className='user-cell'>Emmah@gmail.com</td>
									<td className='user-cell'>Emmah</td>
									<td className='user-cell'>123452</td>
								</tr>
								<tr>
									<td className='user-cell'>Emmah@gmail.com</td>
									<td className='user-cell'>Emmah</td>
									<td className='user-cell'>123452</td>
								</tr>
								<tr>
									<td className='user-cell'>Emmah@gmail.com</td>
									<td className='user-cell'>Emmah</td>
									<td className='user-cell'>123452</td>
								</tr>
								{/* {users.map((user) => (
						<tr key={user.id}>
							<td>{user.email}</td>
							<td>{user.name}</td>
							<td>{user.password}</td>
						</tr>
					))} */}
							</tbody>
						</table>
					</>
				}
			/>
		</div>
	);
}

export default UserTable;
