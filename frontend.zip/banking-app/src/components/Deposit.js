import React from 'react';
import Card from './common/CardComponent';

export function Deposit() {
	const [show, setShow] = React.useState(true);
	const [status, setStatus] = React.useState('');
	const [name, setName] = React.useState('');
	const [email, setEmail] = React.useState('');
	const [password, setPassword] = React.useState('');
	// const ctx = React.useContext(UserContext);

	function validate(field, label) {
		if (!field) {
			setStatus('Error: ' + label);
			setTimeout(() => setStatus(''), 3000);
			return false;
		}
		return true;
	}

	function handleCreate() {
		console.log(name, email, password);
		if (!validate(name, 'name')) return;
		if (!validate(email, 'email')) return;
		if (!validate(password, 'password')) return;
		// ctx.users.push({ name, email, password, balance: 100 });
		setShow(false);
	}

	function clearForm() {
		setName('');
		setEmail('');
		setPassword('');
		setShow(true);
	}

	return (
		<Card
			bgcolor='primary'
			header='DEPOSIT'
			status={status}
			body={
				<>
					<br />
					<br />
					Balance
					<input
						style={{ width: '20%', height: '35px', marginLeft: '50px' }}
						type='input'
						className='form-control'
						id='name'
						placeholder='35.0'
						value={name}
						onChange={(e) => setName(e.currentTarget.value)}
					/>
					<br />
					<br />
					Deposit Amount
					<br />
					<input
						style={{ width: '50%', height: '35px' }}
						type='input'
						className='form-control'
						id='email'
						placeholder='20.0'
						value={email}
						onChange={(e) => setEmail(e.currentTarget.value)}
					/>
					<br /> <br /> <br />
					<button
						type='submit'
						className='btn btn-light'
						onClick={handleCreate}
					>
						Deposit{' '}
					</button>
				</>
			}
		/>
	);
}
