import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';

import UserTable from './components/AllData';
import Balance from './components/Balance';
// import { CreateAccount } from './components/CreateAccount';
import { Deposit } from './components/Deposit';
import Home from './components/HomePage';
import Login from './components/Login';
import Navbar from './components/Navbar';
import Registration from './components/Register';
import { Withdraw } from './components/Withdraw';
function App() {
	return (
		<Router>
			<div>
				<Navbar />
				<Routes>
					<Route path='/' exact element={<Home />} />
					<Route path='/create-account' element={<Registration />} />
					<Route path='/login' element={<Login />} />

					<Route path='/withdraw' element={<Withdraw />} />
					<Route path='/deposit' element={<Deposit />} />
					<Route path='/balance' element={<Balance />} />
					<Route path='/all-data' element={<UserTable />} />
				</Routes>
				{/* <CreateAccount /> */}
				{/* <Withdraw />
				<Balance />
				<Login />
				<Deposit />
				<UserTable />
				<Registration /> */}
				{/* <Routes>
				<Route index element={<CreateAccount />} />
				<Route path='/create-account' element={<CreateAccount />} />
			</Routes> */}
			</div>
		</Router>
	);
}

export default App;
